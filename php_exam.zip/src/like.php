<?php
// Initialize the session
session_start();

// Include config file
require_once "config.php";

// Prepare a select statement
$sql = "SELECT id_users FROM likes WHERE id_topic = ?";
        
if($stmt = mysqli_prepare($link, $sql)){
    // Bind variables to the prepared statement as parameters
    mysqli_stmt_bind_param($stmt, "i", $param_id_user);
    
    // Set parameters
    $param_id_user = htmlspecialchars($_SESSION["id"]);
    
    // Attempt to execute the prepared statement
    if(mysqli_stmt_execute($stmt)){
        /* store result */
        mysqli_stmt_store_result($stmt);
        
        if(mysqli_stmt_num_rows($stmt) == 1){
            $sql = "DELETE FROM likes WHERE id_users = ?";
            
            if($stmt = mysqli_prepare($link, $sql)){
                mysqli_stmt_bind_param($stmt, "i", $param_id_user);
            }

        } else {
           
            $sql = "INSERT INTO likes (id_users, id_topic) VALUES (?, ?)";
    
            if($stmt = mysqli_prepare($link, $sql)){
    
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ii", $param_id_users, $param_id_topic);
            
            $param_id_user = htmlspecialchars($_SESSION["id"]);
            $param_id_topic = str_replace(['/forumPhp/src/topic/', '/like.php'], '', $_SERVER['REQUEST_URI']);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to new page
                header("location: ../home.php");
            } else {
                echo "* Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
}        }
    } else {
        echo "* Oops! Something went wrong. Please try again later.";
    }
    // Close statement
    mysqli_stmt_close($stmt);
}

mysqli_close($link);
