<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: home.php");
    exit;
}
 
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = $login_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, username, password FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;                            
                            
                            // Redirect user to welcome page
                            header("location: home.php");
                        } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid username or password.";
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid username or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="/forumPhp/dist/output.css" rel="stylesheet">
</head>

<body class= "container box-border">
    <div class = "fixed top-0 bg-gray-900 w-full h-12">
        <div class = "flex-line space-x-4 text-center text-gray-300 shadow rounded">
            <a class="hover:text-gray-400" href="home.php">Home</a> 
            <a class="hover:text-gray-400" href="new.php">New</a> 
            <a class="hover:text-gray-400" href="details.php">Details</a> 
            <a class="hover:text-gray-400" href="edit.php">Edit</a> 
            <a class="hover:text-gray-400" href="account.php">Account</a> 
            <a class="hover:text-gray-400" href="admin.php"> Connexion Admin et Panel Admin</a> 
        </div>
    </div>
    
    <div class="fixed bg-gray-900 w-full border-t-2 bottom-0 border-gray-600 text-center pt-1 z-0">
        <span class="font-sans font-medium text-white select-none">We Make With Love &#x2764;</span>
    </div>
    
    <div class="absolute w-full top-20 font-normal flex flex-wrap">
        <div class="rounded border-2 mx-auto">
            <div class="flex flex-col p-5 select-none">
            <?php 
                if(!empty($login_err)){
                    echo '<div>' . $login_err . '</div>';
                }        
            ?>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                    <div class="text-2xl font-medium text-center">Login</div>
                        <div class="flex flex-col mx-auto space-x-4 p-1">
                            <div>
                                <a>Username:</a>
                                <input name="username" class="text-gray-600 border-2 border-light-gray-500 " value="<?php echo $username?>">
                            </div>
                            <span class="text-gray-600"><?php echo $username_err; ?></span>
                        </div>
                        <div class="flex flex-col mx-auto space-x-4 p-1">
                            <div>
                                <a>Password:</a>
                                <input type="password" name="password" class="text-gray-600 border-2 border-light-gray-500" value="<?php echo $password?>">
                            </div>
                            <span class="text-gray-600"><?php echo $password_err; ?></span>
                        </div>
                        <div class="px-32 py-3">
                            <input type="submit" class="px-2 py-1 bg-gray-900 text-gray-50 hover:text-gray-400 rounded" value="Login">
                        </div>
                        <div>Don't have an account? <span><a class="text-blue-600 hover:text-blue-900 hover:underline" href="register.php">Sign up now</a></span>.</div>
                </form>
            </div>
        </div>
    </div>

</body>
</html>