<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="/forumPhp/dist/output.css" rel="stylesheet">
</head>
<body class= "container">
    <div class = "fixed top-0 bg-gray-900 w-full h-12 ">
        <div class = "flex-line space-x-4 text-center text-gray-300 shadow rounded">
          <a class="hover:text-gray-400" href="home.php">Home</a> 
          <a class="hover:text-gray-400" href="new.php">New</a> 
          <a class="hover:text-gray-400" href="details.php"></a> 
          <a class="hover:text-gray-400" href="edit.html">Edit</a> 
          <a class="hover:text-gray-400" href="account.html">Account</a> 
          <a class="hover:text-gray-400" href="admin.html"> Connexion Admin et Panel Admin</a> 
        </div>
    </div>

    <div class = "absolute rounded border-2 text-gray-900 top-32 "></div> 


  <div class="fixed bg-gray-900 w-full border-t-2 bottom-0 border-gray-600 text-center pt-1 z-0">
    <span class="font-sans font-medium text-white select-none">We Make With Love &#x2764;</span>
</div>
</body>
</html>