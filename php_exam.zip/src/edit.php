<?php

// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

// Include config file
require_once "config.php";
 
$name_err = $theme_err = "";


// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
      
  if(empty(trim($_POST["name"])) || empty(trim($_POST["theme"]))){
    
  $name_err = "* Please enter a Name.";
  $theme_err = "* Please enter your Theme.";
  
  } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["name"])) || !preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["theme"]))){
    
    $name_err = "* Name can only contain letters, numbers, and underscores.";
    $theme_err = "* Theme can only contain letters, numbers, and underscores.";

  } 
    
    // Check input errors before inserting in database
    if(empty($name_err) && empty($theme_err)) {
        
        // Prepare an insert statement
        $sql = "UPDATE topics_table set name, theme = ? WHERE id = ?";
         
        if($stmt = mysqli_prepare($link, $sql)){
            
          // Bind variables to the prepared statement as parameters
          mysqli_stmt_bind_param($stmt, "ss", $param_name, $param_theme);
          
          $param_name = trim($_POST["name"]);
          $param_theme = trim($_POST["theme"]);
          
          // Attempt to execute the prepared statement
          if(mysqli_stmt_execute($stmt)){
              // Redirect to login page
              header("location: home.php");
          } else {
              echo "* Oops! Something went wrong. Please try again later.";
          }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}

?>
<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="/forumPhp/dist/output.css" rel="stylesheet">
</head>
<body class= "container">
<div class = "absolute flex flex-row top-0 bg-gray-900 w-full h-12">
    <div class = "flex-line space-x-4 mx-auto text-center text-gray-300 shadow rounded">
        <a class="hover:text-gray-400" href="home.php">Home</a> 
        <a class="hover:text-gray-400" href="new.php">New</a>  
        <a class="hover:text-gray-400" href="edit.php">Edit</a> 
        <a class="hover:text-gray-400" href="account.php">Account</a> 
        <a class="hover:text-gray-400" href="admin.php"> Connexion Admin et Panel Admin</a> 
    </div>
    <div class="absolute flex flex-row right-0">
      <span class="text-gray-300">(<?php echo htmlspecialchars($_SESSION["username"]); ?>) 
        <a class="text-blue-300 hover:text-blue-600 right-0 mr-6 mb-8" href="logout.php">Sign out</a>
      </span>.
    </div>
  </div>
  
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class = "m-auto top-16 relative flex flex-col space-y-4 content-center w-96 max-h-min ml-80 mt-12 text-gray-600 text-center border-2 border-light-gray-500 p-3"
    method="POST">
      <div class="rounded border-2 mx-auto px-6"><p><i><b>La rédaction de votre Topic</b></i></p></div>
      <div class="flex flex-col">
        <span>Nom votre topic</span>
        <input type="text" name="name" class = "mx-auto top-12 h-10 w-80 text-gray-900 border-2 border-light-gray-500">
        <div><?php echo $name_err ?></div>
      </div>
      <div class="flex flex-col">
        <span>Votre theme</span> 
        <input type="text" name="theme" class = "mx-auto top-12 h-10 w-80 text-gray-900 border-2 border-light-gray-500">
        <div><?php echo $theme_err ?></div>
      </div>
      <div class = "mx-auto bg-gray-900 text-gray-50">
        <button type="submit" class = "hover:text-gray-400 w-16 h-8">Changer</button>
      </div>
    </form>

  <div class="fixed bg-gray-900 w-full border-t-2 bottom-0 border-gray-600 text-center pt-1 z-0">
    <span class="font-sans font-medium text-white select-none">We Make With Love &#x2764;</span>
</div>
</body>
</html>