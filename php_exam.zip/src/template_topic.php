<?php
// Initialize the session
session_start();

// Include config file
require_once "../config.php";
 
$comments_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
      
      if(empty(trim($_POST["comment"]))){
        $comment_err = "* Please enter a comment.";      
      }   
    
    // Check input errors before inserting in database
    if(empty($comment_err) ) {
        
        // Prepare an insert statement

        $sql = "INSERT INTO comments (text, id_topic) VALUES (?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            
          // Bind variables to the prepared statement as parameters
          mysqli_stmt_bind_param($stmt, "ss", $param_comment, $param_id_topic);
          
          $param_comment = trim($_POST["comment"]);
          $param_id_topic = str_replace(['/forumPhp/src/topic/', '.php'], '', $_SERVER['REQUEST_URI']);
          
          // Attempt to execute the prepared statement
          if(mysqli_stmt_execute($stmt)){
            
              // Redirect to login page
              header("location: ".$param_id_topic.".php");
          } else {
              echo "* Oops! Something went wrong. Please try again later.";
          }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}

?>

<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="/forumPhp/dist/output.css" rel="stylesheet">
</head>
<body class= "container">
<div class = "absolute flex flex-row top-0 bg-gray-900 w-full h-12">
    <div class = "flex-line space-x-4 mx-auto text-center text-gray-300 shadow rounded">
        <a class="hover:text-gray-400" href="../home.php">Home</a> 
        <a class="hover:text-gray-400" href="../new.php">New</a>  
        <a class="hover:text-gray-400" href="../edit.php">Edit</a> 
        <a class="hover:text-gray-400" href="../account.php">Account</a> 
        <a class="hover:text-gray-400" href="../admin.php"> Connexion Admin et Panel Admin</a> 
    </div>
    <div class="absolute flex flex-row right-0">
      <span class="text-gray-300">(<?php echo htmlspecialchars($_SESSION["username"]); ?>) 
        <a class="text-blue-300 hover:text-blue-600 right-0 mr-6 mb-8" href="logout.php">Sign out</a>
      </span>.
    </div>
  </div>
  
  <div class="absolute pl-6 top-32 flex flex-wrap">
    <div class="w-64 border-2 m-3">
      <?php
      
      foreach ($link->query('SELECT * from topics_table WHERE id = '.str_replace(['/forumPhp/src/topic/', '.php'], '', $_SERVER['REQUEST_URI'])) as $row) {
        echo '<div class="space-y-5 text-gray-900 select-none">
        <div class="mx-6 mt-4 pt-2 rounded border-2">
          <span class="ml-6">'.$row["name"].'</span>  
        </div>
        <div class="ml-6 mr-6 pt-2 rounded border-2">
          <span class="ml-6">'.$row["theme"].'</span> 
        </div>
      </div>';
      }

      ?>
        <div class="mt-3 relative inset-x-0 bottom-0 left-0 h-10 bg-gray-900"></div>
    </div>
    <div class="flex flex-col w-auto h-10">
      <form class="text-center" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
        <span>Commentaires</span>
        <div class = "flex flex-row border-2 border-light-gray-500 text-gray-900">
          <textarea type="text" name="comment" class="mx-6 my-3 h-12 resize-none"></textarea>
          <button type="submit" class="px-2 py-1 bg-gray-900 text-gray-50 hover:text-gray-400 rounded my-3 mr-3">Send</button>
        </div>
      </form>
      <?php 
    
      foreach($link->query('SELECT * from comments WHERE id_topic = '.str_replace(['/forumPhp/src/topic/', '.php'], '', $_SERVER['REQUEST_URI'])) as $row) {
        echo '
        <div class = "border-2 m-3 pt-2"><span class="mx-6">'.$row['text'].'</span></div>';
    }
      ?>
    </div>
    
  </div>
  <div class="fixed bg-gray-900 w-full border-t-2 bottom-0 border-gray-500 text-center pt-1 z-0">
    <span class="font-sans font-medium  text-white select-none">We Make With Love &#x2764;</span>
  </div>
</body>
</html>