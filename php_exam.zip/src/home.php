<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="/forumPhp/dist/output.css" rel="stylesheet">
</head>
<body class= "container">
  <div class = "absolute flex flex-row top-0 bg-gray-900 w-full h-12">
    <div class = "flex-line space-x-4 mx-auto text-center text-gray-300 shadow rounded">
        <a class="hover:text-gray-400" href="home.php">Home</a> 
        <a class="hover:text-gray-400" href="new.php">New</a>  
        <a class="hover:text-gray-400" href="edit.php">Edit</a> 
        <a class="hover:text-gray-400" href="account.php">Account</a> 
        <a class="hover:text-gray-400" href="admin.php"> Connexion Admin et Panel Admin</a> 
    </div>
    <div class="absolute flex flex-row right-0">
      <span class="text-gray-300">(<?php echo htmlspecialchars($_SESSION["username"]); ?>) 
        <a class="text-blue-300 hover:text-blue-600 right-0 mr-6 mb-8" href="logout.php">Sign out</a>
      </span>.
    </div>
  </div>
  
  <div class="absolute pl-6 top-32 flex flex-wrap">
    
    <?php 
    
    require_once "config.php";
    
    foreach($link->query('SELECT * from topics_table') as $row) {
        echo '
        <div class="w-64 border-2 m-3">
          <div class="space-y-5 text-gray-900 select-none">
            <div class="mx-6 mt-4 pt-2 rounded border-2">
              <span class="ml-6">'.$row["name"].'</span>  
            </div>
            <div class="ml-6 mr-6 pt-2 rounded border-2">
              <span class="ml-6">'.$row["theme"].'</span> 
            </div>
          </div>
            <div class="mt-3 relative inset-x-0 bottom-0 left-0 h-10 bg-gray-900">
              <button class="absolute bottom-0 left-0 bg-gray-300 hover:bg-gray-500 scale-150 ml-3 mb-2 w-10" onclick="location.href = &#39topic/'.$row["id"].'.php&#39">&#10000;</button>
              <button class="absolute bottom-0 right-0 bg-gray-300 hover:bg-gray-500 scale-150 mr-3 mb-2 w-10 onclick="location.href = &#39like.php&#39">&#9829;</button>
            </div>
        </div>';
    }
    ?>

  </div>
  <div class="fixed bg-gray-900 w-full border-t-2 bottom-0 border-gray-500 text-center pt-1 z-0">
    <span class="font-sans font-medium  text-white select-none">We Make With Love &#x2764;</span>
  </div>
</body>
</html>